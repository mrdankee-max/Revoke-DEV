import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:installed_apps/installed_apps.dart';
import 'package:sing_box/sing_box.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

/// Сборка для разработчика: flutter build apk --dart-define=CVPN_DEV=true
const bool kDev = bool.fromEnvironment('CVPN_DEV');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SingBox.instance.initialize(
    const SingBoxOptions(
      android: SingBoxAndroidOptions(
        notificationTitle: 'Revoke',
        showTrafficInNotification: true,
        stopActionTitle: 'Disconnect',
      ),
    ),
  );
  runApp(const RevokeApp());
}

class RevokeApp extends StatelessWidget {
  const RevokeApp({super.key});

  @override
  Widget build(BuildContext context) => const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: RevokeHome(),
      );
}

class RevokeHome extends StatefulWidget {
  const RevokeHome({super.key});

  @override
  State<RevokeHome> createState() => _RevokeHomeState();
}

class _RevokeHomeState extends State<RevokeHome> {
  WebViewController? _web;
  StreamSubscription? _statsSub;
  StreamSubscription? _stateSub;
  bool _pageReady = false;
  bool _busy = false;
  static const MethodChannel _tile = MethodChannel('cvpn/tile');
  int? _limitBytes; // сколько байт осталось по тарифу на эту сессию (null — без лимита)

  @override
  void initState() {
    super.initState();
    _tile.setMethodCallHandler((c) async {
      if (c.method == 'toggle') _tileToggle();
      return null;
    });
    _init();
  }

  /// Нажатие на плитку быстрых настроек: имитируем нажатие кнопки питания в интерфейсе.
  void _tileToggle() {
    _web?.runJavaScript('window.cvpnToggle&&window.cvpnToggle()');
  }

  Future<void> _init() async {
    final controller = WebViewController();
    _web = controller;
    await controller.setJavaScriptMode(JavaScriptMode.unrestricted);
    await controller.setBackgroundColor(const Color(0xFF050505));
    await controller.enableZoom(false);
    await controller.addJavaScriptChannel(
      'VpnBridge',
      onMessageReceived: (message) => _onBridge(message.message),
    );
    await controller.setNavigationDelegate(
      NavigationDelegate(
        onPageFinished: (_) {
          _pageReady = true;
          if (kDev) {
            controller.runJavaScript('window.CVPN_DEV=true;window.__cvpnSetDev&&window.__cvpnSetDev();');
          }
          _sendState(SingBox.instance.status.isActive ? 'connected' : 'disconnected');
          _tile.invokeMethod('pending').then((p) {
            if (p == true) _tileToggle();
          }).catchError((_) {});
        },
      ),
    );
    // <input type=file> in the page (custom background upload)
    final plat = controller.platform;
    if (plat is AndroidWebViewController) {
      await plat.setOnShowFileSelector((params) async {
        controller.runJavaScript("window.cyMsg&&window.cyMsg('Opening gallery…')");
        try {
          final path = await _tile.invokeMethod<String>('pickMedia');
          if (path == null) return <String>[];
          return <String>[Uri.file(path).toString()];
        } catch (e) {
          final m = e.toString().replaceAll("'", ' ').replaceAll('\n', ' ');
          controller.runJavaScript("window.cyMsg&&window.cyMsg('Gallery error: $m')");
          return <String>[];
        }
      });
    }
    await controller.loadFlutterAsset('assets/index.html');

    _statsSub = SingBox.instance.watchConnectionStats().listen((s) {
      _sendStats({
        'download': _formatBytes(s.downloadTotal),
        'upload': _formatBytes(s.uploadTotal),
        'time': _formatDuration(s.duration),
        'rxBytes': s.downloadTotal.toInt(),
        'txBytes': s.uploadTotal.toInt(),
      });
      final lim = _limitBytes;
      if (lim != null && !_busy && (s.downloadTotal + s.uploadTotal) >= lim) {
        _limitBytes = null;
        _disconnect(reason: 'limit');
      }
    });

    _stateSub = SingBox.instance.watchConnectionState().listen((s) {
      if (s.error != null) {
        _sendState('error', s.error.toString());
      }
    });

    if (mounted) setState(() {});
  }

  /// Custom background: system picker -> file bytes -> page (base64 chunks).
  Future<void> _pickBg() async {
    final c = _web;
    if (c == null) return;
    Future<void> say(String m) => c.runJavaScript(
        "window.cyMsg&&window.cyMsg('${m.replaceAll("'", ' ').replaceAll('\n', ' ')}')");
    try {
      final path = await _tile.invokeMethod<String>('pickMedia');
      if (path == null) {
        await say('Nothing selected');
        return;
      }
      final f = File(path);
      final len = await f.length();
      if (len > 150 * 1024 * 1024) {
        await say('File is too big (max 150 MB)');
        return;
      }
      final video = path.endsWith('.mp4');
      await c.runJavaScript("window.cyBgBegin('${video ? 'video/mp4' : 'image/jpeg'}')");
      final raf = await f.open();
      const chunk = 786432; // multiple of 3 -> clean base64 pieces
      for (var off = 0; off < len; off += chunk) {
        final b = await raf.read(chunk);
        await c.runJavaScript("window.cyBgChunk('${base64Encode(b)}')");
      }
      await raf.close();
      await c.runJavaScript('window.cyBgEnd()');
    } catch (e) {
      await say('Gallery error: $e');
    }
  }

  String _formatBytes(num value) {
    if (value < 1024) return '${value.toInt()} B';
    if (value < 1024 * 1024) return '${(value / 1024).toStringAsFixed(1)} KB';
    if (value < 1024 * 1024 * 1024) return '${(value / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(value / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  String _formatDuration(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return '${two(h)}:${two(m)}:${two(s)}';
  }

  Future<void> _onBridge(String raw) async {
    Map<String, dynamic> data;
    try {
      data = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final action = data['action'];
    if (action == 'copy') {
      await Clipboard.setData(ClipboardData(text: (data['text'] ?? '').toString()));
      return;
    }
    if (action == 'listApps') {
      await _listApps();
      return;
    }
    if (action == 'applyTunnel') {
      final err = await _applyRouting(_modeOf(data), _appsOf(data));
      _sendEvent('vpnapplied', {'ok': err == null, if (err != null) 'message': err});
      return;
    }
    if (action == 'pickBg') {
      await _pickBg();
      return;
    }
    if (action == 'openUrl') {
      final url = (data['url'] ?? '').toString();
      if (url.startsWith('https://t.me/') || url.startsWith('tg://')) {
        try {
          await _tile.invokeMethod('openUrl', url);
        } catch (_) {}
      }
      return;
    }
    if (_busy) return;
    switch (action) {
      case 'connect':
        await _connect(data);
        break;
      case 'disconnect':
        await _disconnect();
        break;
    }
  }

  String _modeOf(Map<String, dynamic> data) => (data['mode'] ?? 'all').toString();

  List<String> _appsOf(Map<String, dynamic> data) =>
      ((data['apps'] as List?) ?? const []).map((e) => e.toString()).toList();

  /// Список установленных приложений для окна «Раздельное туннелирование».
  Future<void> _listApps() async {
    try {
      final apps = await InstalledApps.getInstalledApps(excludeSystemApps: false);
      final list = apps
          .where((a) => !a.packageName.startsWith('com.zephyy.claudevpn'))
          .map((a) => {'n': a.name, 'p': a.packageName})
          .toList();
      _sendEvent('vpnapps', {'apps': list});
    } catch (e) {
      _sendEvent('vpnapps', {'apps': <Map<String, String>>[], 'error': e.toString()});
    }
  }

  /// mode: all | exclude (не туннелировать выбранные) | include (только выбранные).
  /// Возвращает null при успехе или текст ошибки.
  Future<String?> _applyRouting(String mode, List<String> apps) async {
    final proxy = mode == 'include' ? apps : <String>[];
    final bypass = mode == 'exclude' ? apps : <String>[];
    try {
      await SingBox.instance.updateRoutingRules(
        (r) => (r as dynamic).copyWith(proxyApps: proxy, bypassApps: bypass),
      );
      return null;
    } catch (_) {}
    try {
      await SingBox.instance.updateRoutingRules(
        (r) => (r as dynamic).copyWith(proxyApps: proxy.toSet(), bypassApps: bypass.toSet()),
      );
      return null;
    } catch (_) {}
    try {
      await SingBox.instance.setProxyApps(proxy);
      for (final app in bypass) {
        await SingBox.instance.addAppToBypass(app);
      }
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  /// Серверы лежат в assets/servers.json: массив sing-box outbound'ов,
  /// сконвертированный из исходного Xray-конфига. sing_box сам собирает из
  /// массива селектор `proxy` с автоматическим urltest (`auto`).
  Future<void> _connect(Map<String, dynamic> data) async {
    _busy = true;
    final lim = data['limit'];
    _limitBytes = lim is num ? lim.toInt() : null;
    _sendState('connecting');
    try {
      await _applyRouting(_modeOf(data), _appsOf(data));
      final servers = await rootBundle.loadString('assets/servers.json');
      await SingBox.instance.connect(servers);
      _sendState('connected');
    } on SingBoxException catch (e) {
      _limitBytes = null;
      _sendState('error', e.message);
    } catch (e) {
      _sendState('error', e.toString());
    } finally {
      _busy = false;
    }
  }

  Future<void> _disconnect({String? reason}) async {
    _busy = true;
    _limitBytes = null;
    try {
      await SingBox.instance.disconnect();
      _sendEvent('vpnstate', {'state': 'disconnected', if (reason != null) 'reason': reason});
    } catch (e) {
      _sendState('error', e.toString());
    } finally {
      _busy = false;
    }
  }

  void _sendEvent(String name, Map<String, dynamic> detail) {
    if (!_pageReady) return;
    final payload = jsonEncode(detail);
    _web?.runJavaScript(
      "window.dispatchEvent(new CustomEvent('$name',{detail:$payload}));",
    );
  }

  void _sendState(String state, [String? message]) {
    _sendEvent('vpnstate', {'state': state, if (message != null) 'message': message});
    _tile.invokeMethod<void>('state', state == 'connected' || state == 'connecting').catchError((_) {});
  }

  void _sendStats(Map<String, dynamic> stats) => _sendEvent('vpnstats', stats);

  @override
  void dispose() {
    _statsSub?.cancel();
    _stateSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_web == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF050505),
        body: Center(child: CircularProgressIndicator(color: Color(0xFFFF6A1F))),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      body: SafeArea(child: WebViewWidget(controller: _web!)),
    );
  }
}
