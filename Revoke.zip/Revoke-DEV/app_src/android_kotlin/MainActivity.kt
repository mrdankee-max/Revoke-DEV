package ru.revoke.app

import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var channel: MethodChannel? = null
    private var pickResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "cvpn/tile")
        channel = ch
        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "pending" -> { val p = pending; pending = false; result.success(p) }
                "openUrl" -> {
                    try {
                        val u = call.arguments as? String
                        if (u != null && (u.startsWith("https://t.me/") || u.startsWith("tg://"))) {
                            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u)))
                        }
                    } catch (e: Exception) {}
                    result.success(null)
                }
                "pickMedia" -> {
                    if (pickResult != null) { pickResult = null }
                    run {
                        pickResult = result
                        try {
                            // Android system picker: user grants access only to the chosen image/video.
                            // This is the recommended modern Android flow and does not need broad gallery permission.
                            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                            i.addCategory(Intent.CATEGORY_OPENABLE)
                            i.type = "*/*"
                            i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            startActivityForResult(i, 4711)
                        } catch (e: Exception) { pickResult = null; result.error("pick", e.toString(), null) }
                    }
                }
                "state" -> { VpnTileService.setActive(this, (call.arguments as? Boolean) ?: false); result.success(null) }
                else -> result.notImplemented()
            }
        }
        handle(intent, false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent, true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 4711) {
            val r = pickResult
            pickResult = null
            var path: String? = null
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null) {
                try {
                    val ext = if ((contentResolver.getType(uri) ?: "").startsWith("video")) "mp4" else "img"
                    val f = java.io.File(cacheDir, "bg_pick." + ext)
                    contentResolver.openInputStream(uri)?.use { inp -> f.outputStream().use { out -> inp.copyTo(out) } }
                    path = f.absolutePath
                } catch (e: Exception) { path = null }
            }
            r?.success(path)
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun handle(i: Intent?, live: Boolean) {
        if (i?.action == VpnTileService.ACTION_TOGGLE) {
            i.action = null
            if (live) channel?.invokeMethod("toggle", null) else pending = true
        }
    }

    companion object { @Volatile var pending = false }
}
