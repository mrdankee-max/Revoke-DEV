package ru.revoke.app

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Плитка быстрых настроек: нажатие включает/выключает VPN через приложение. */
class VpnTileService : TileService() {
    companion object {
        const val ACTION_TOGGLE = "com.zephyy.claudevpn.TOGGLE"
        private const val PREFS = "cvpn_tile"

        fun setActive(c: Context, active: Boolean) {
            c.getSharedPreferences(PREFS, 0).edit().putBoolean("a", active).apply()
            try {
                TileService.requestListeningState(c, ComponentName(c, VpnTileService::class.java))
            } catch (e: Exception) {}
        }
    }

    override fun onStartListening() = refresh()

    private fun refresh() {
        val t = qsTile ?: return
        val a = getSharedPreferences(PREFS, 0).getBoolean("a", false)
        t.state = if (a) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Revoke"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (a) "Подключено" else "Отключено"
        t.updateTile()
    }

    override fun onClick() {
        val i = Intent(this, MainActivity::class.java).apply {
            action = ACTION_TOGGLE
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
