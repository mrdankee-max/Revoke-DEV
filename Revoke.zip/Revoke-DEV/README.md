Revoke DEV update: Shader Panel applies to Dock Panel surface only. Effects: Ripple, Neon Flow, Carbon, Prism. Color wheel controls accent color.
